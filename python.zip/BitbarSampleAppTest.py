##
## Example script for parallel selenium tests
##
import os
import unittest
import xmlrunner
from time import sleep
from TestdroidAppiumTest import TestdroidAppiumTest, log
from selenium.common.exceptions import WebDriverException
from altunityrunner import *

class BitbarSampleAppTest(TestdroidAppiumTest):

    altdriver = None
    driver = None
    platform = "android"

    def setUp(self):
        # TestdroidAppiumTest takes settings (local or cloud) from environment variables
        super(BitbarSampleAppTest, self).setUp()
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['deviceName'] = 'device'
        desired_caps['app'] = os.environ.get('APPIUM_APPFILE')
        driver = self.get_driver()  # Initialize Appium connection to device
        self.altdriver = AltrunUnityDriver(self.driver, self.platform)
    
    # Test start.    
    def test_start_game(self):
        self.altdriver.wait_for_current_scene_to_be('SecurityRoom')
        self.altdriver.wait_for_element('Player')

        self.altdriver.wait_for_element('GuardInteractable').tap()
        self.altdriver.wait_for_element_with_text('MessageText', 'Get lost!')
        self.altdriver.wait_for_element_with_text('MessageText', '')

        self.altdriver.wait_for_element('PictureInteractable').tap()
        self.altdriver.wait_for_element_with_text('MessageText', 'He looks pretty trustworthy.')
        self.altdriver.wait_for_element_with_text('MessageText', '')

        self.altdriver.wait_for_element('LaserGridInteractable').tap()
        self.altdriver.wait_for_element_with_text('MessageText', 'ACCESS DENIED!')
        self.altdriver.wait_for_element_with_text('MessageText', '')

    # Test end.

if __name__ == '__main__':
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test-reports'))
